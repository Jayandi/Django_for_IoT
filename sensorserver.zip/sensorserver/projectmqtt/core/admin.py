from django.contrib import admin
from core.models import Messages

admin.site.register(Messages)